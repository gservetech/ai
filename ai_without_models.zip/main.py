import pandas as pd
import os
import numpy as np
import time
from sklearn.feature_extraction.text import TfidfVectorizer
from diskcache import Cache

# Cache settings
CACHE_DIR = os.path.join(os.path.dirname(__file__), '.cache')
CACHE_EXPIRY = 60 * 60 * 24 * 7  # 1 week in seconds

# In-memory cache to avoid repeated disk reads in same session
_memory_cache = {}


def load_data():
    """Load the Excel file from data folder into a pandas DataFrame."""
    data_path = os.path.join(os.path.dirname(__file__), 'data', 'institutional_aum.xlsx')
    df = pd.read_excel(data_path)

    # Convert datetime columns to string to avoid serialization issues with cache
    for col in df.columns:
        if df[col].dtype == 'datetime64[ns]' or 'datetime' in str(df[col].dtype).lower():
            df[col] = df[col].astype(str)
        elif df[col].dtype == 'object':
            # Convert all object columns to string to avoid mixed type issues
            # This fixes Arrow serialization errors like "Expected bytes, got 'int'"
            df[col] = df[col].astype(str)

    return df


def get_text_for_vectorization(df: pd.DataFrame) -> list[str]:
    """Convert DataFrame rows to text for vectorization."""
    texts = []
    for _, row in df.iterrows():
        # Combine all column values into a single text string
        text = ' '.join([f"{col}: {str(val)}" for col, val in row.items() if pd.notna(val)])
        texts.append(text)
    return texts


def vectorize_data(texts: list[str]) -> tuple[np.ndarray, TfidfVectorizer]:
    """Vectorize text data using TF-IDF."""
    vectorizer = TfidfVectorizer(max_features=512)
    embeddings = vectorizer.fit_transform(texts).toarray()
    return embeddings, vectorizer


def get_cached_vectors(force_refresh: bool = False):
    """Get vectorized data from cache or compute and cache it.

    Args:
        force_refresh: If True, ignore cache and reload from Excel file.
    """
    cache_key = 'institutional_aum_vectors'

    # Check in-memory cache first (fastest)
    if not force_refresh and cache_key in _memory_cache:
        print("Loading from memory cache (instant)...")
        return _memory_cache[cache_key]

    start = time.time()
    cache = Cache(CACHE_DIR)
    print(f"Cache opened in {time.time() - start:.3f}s")

    # Check if cached data exists and is still valid (unless force refresh)
    if not force_refresh:
        start = time.time()
        cached_data = cache.get(cache_key)
        print(f"Cache lookup in {time.time() - start:.3f}s")
        if cached_data is not None:
            print("Loading vectors from disk cache...")
            cache.close()
            result = (cached_data['vectors'], cached_data['df'], cached_data['vectorizer'])
            _memory_cache[cache_key] = result  # Store in memory for next call
            return result

    print("Cache miss or force refresh. Computing vectors...")

    # Load data
    df = load_data()

    # Convert to text
    texts = get_text_for_vectorization(df)

    # Vectorize using TF-IDF (works offline, no download needed)
    vectors, vectorizer = vectorize_data(texts)

    # Cache the results for 1 week
    cache.set(cache_key, {'vectors': vectors, 'df': df, 'vectorizer': vectorizer}, expire=CACHE_EXPIRY)
    print(f"Vectors cached for {CACHE_EXPIRY // (3600 * 24)} days")

    cache.close()
    result = (vectors, df, vectorizer)
    _memory_cache[cache_key] = result  # Store in memory for next call
    return result


if __name__ == '__main__':
    vectors, df, vectorizer = get_cached_vectors()
    print(f"\nData loaded successfully!")
    print(f"DataFrame Shape: {df.shape}")
    print(f"Vectors Shape: {vectors.shape}")
    print(f"\nFirst 5 rows:")
    print(df.head())

    # Print first 10 records of vector tokens
    print(f"\n--- First 10 Vector Records ---")
    feature_names = vectorizer.get_feature_names_out()
    for i in range(min(10, len(vectors))):
        non_zero_indices = np.where(vectors[i] > 0)[0]
        tokens = [(feature_names[idx], round(vectors[i][idx], 4)) for idx in non_zero_indices]
        print(f"Record {i+1}: {tokens[:10]}...")  # Show first 10 tokens per record
