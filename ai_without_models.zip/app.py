import streamlit as st
import re
import json
import os
import plotly.express as px
import matplotlib.pyplot as plt
import seaborn as sns
from pandas.plotting import andrews_curves
from datetime import datetime
from sklearn.metrics.pairwise import cosine_similarity
from main import get_cached_vectors

# --- MODEL CONFIGURATION ---
LOCAL_MODEL_PATH = os.path.join(os.path.dirname(__file__), 'models')

# Try importing Transformers (Hugging Face)
try:
    from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
    import torch
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False

# Try importing Ollama (Fallback)
try:
    import ollama
    from ollama import ResponseError
    OLLAMA_AVAILABLE = True
except ImportError:
    OLLAMA_AVAILABLE = False
    ResponseError = None

OLLAMA_MODEL = os.getenv('OLLAMA_MODEL', 'llama3.2')

# --- LOAD LOCAL HUGGING FACE MODEL ---
@st.cache_resource
def load_local_pipeline():
    """Load the local Hugging Face model from the 'models' folder."""
    if not HF_AVAILABLE:
        return None

    if not os.path.exists(LOCAL_MODEL_PATH):
        return None

    try:
        print(f"Loading local model from {LOCAL_MODEL_PATH}...")
        tokenizer = AutoTokenizer.from_pretrained(LOCAL_MODEL_PATH)
        # Load model (uses GPU if available, otherwise CPU)
        model = AutoModelForCausalLM.from_pretrained(
            LOCAL_MODEL_PATH,
            device_map="auto",
            dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            trust_remote_code=True
        )

        pipe = pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            max_new_tokens=512,
            do_sample=True,
            temperature=0.1,
            top_p=0.95
        )
        return pipe
    except Exception as e:
        print(f"Failed to load local model: {e}")
        return None

# Global placeholder (initialized lazily)
hf_pipeline = None

# LLM function to understand natural language queries
def ask_llm(query: str, df_info: str, column_names: list) -> dict:
    """Use Local HF Model or Ollama to understand the user's natural language query."""

    # Construct the system instruction and prompt
    system_prompt = f"""You are a data analyst assistant. Analyze this user's natural language query about a dataset and return a JSON response.
Dataset columns: {column_names}
Dataset info: {df_info}

User query: "{query}"

Understand the user's intent and respond with ONLY valid JSON (no markdown, no explanation):
{{
    "intent": "<intent type>",
    "n": <number of records, default 10>,
    "sort_column": "<column to sort by or null>",
    "sort_order": "desc|asc",
    "filter_column": "<column to filter or null>",
    "filter_operator": "equals|contains|greater_than|less_than|between",
    "filter_value": "<value to filter by or null>",
    "search_column": "<column to search in or null>",
    "search_value": "<text to search for or null>",
    "aggregate_function": "sum|average|count|min|max|null",
    "aggregate_column": "<column to aggregate or null>",
    "chart_type": "bar|line|pie|scatter|histogram|box|heatmap|correlation|none",
    "group_by": "<column to group by or null>",
    "answer": "<natural language answer or explanation>"
}}"""

    # --- STRATEGY 1: Use Local Hugging Face Model ---
    global hf_pipeline
    if HF_AVAILABLE and os.path.exists(LOCAL_MODEL_PATH):
        if hf_pipeline is None:
            # Check if we are already seeing this in the cache
            # But the object isn't global, it's returned by function.
            # We call the cached function.
            with st.spinner("🚀 Loading AI model... (This takes ~1 minute on first run)"):
                hf_pipeline = load_local_pipeline()

    if hf_pipeline:
        try:
            formatted_prompt = f"<|system|>\n{system_prompt}</s>\n<|user|>\n{query}</s>\n<|assistant|>\n"
            outputs = hf_pipeline(formatted_prompt)
            result_text = outputs[0]['generated_text']
            # Extract just the JSON part after <|assistant|>
            if "<|assistant|>" in result_text:
                response_text = result_text.split("<|assistant|>")[-1].strip()
            else:
                response_text = result_text

            # Clean up cleanup response
            response_text = re.sub(r'^```json?\n?', '', response_text)
            response_text = re.sub(r'\n?```$', '', response_text)

            # Find the largest JSON-like block if there's extra text
            json_match = re.search(r'(\{.*\})', response_text, re.DOTALL)
            if json_match:
                response_text = json_match.group(1)

            return json.loads(response_text)
        except Exception as e:
            print(f"Local model error: {e}")

    # --- STRATEGY 2: Use Ollama (Fallback) ---
    if OLLAMA_AVAILABLE:
        try:
            response = ollama.chat(model=OLLAMA_MODEL, messages=[
                {'role': 'user', 'content': system_prompt}
            ])
            response_text = response['message']['content'].strip()
            response_text = re.sub(r'^```json?\n?', '', response_text)
            response_text = re.sub(r'\n?```$', '', response_text)
            return json.loads(response_text)
        except Exception as e:
            return {'_error': 'llm_failure', 'details': str(e)}

    return {'_error': 'no_llm_available', 'details': 'No local model or Ollama connection found.'}



# Feedback file path
FEEDBACK_FILE = os.path.join(os.path.dirname(__file__), '.feedback.json')


# Load existing feedback
def load_feedback():
    if os.path.exists(FEEDBACK_FILE):
        with open(FEEDBACK_FILE, 'r') as f:
            return json.load(f)
    return {'queries': [], 'good_matches': {}, 'query_row_mapping': {}}


# Save feedback
def save_feedback(feedback):
    with open(FEEDBACK_FILE, 'w') as f:
        json.dump(feedback, f, indent=2)


# Get learned keywords from feedback
def get_learned_keywords():
    feedback = load_feedback()
    return feedback.get('good_matches', {})


# Get row boosts based on similar past queries
def get_row_boosts(query, vectorizer, feedback_data):
    """Find similar past queries and boost rows that were marked helpful."""
    query_row_mapping = feedback_data.get('query_row_mapping', {})
    if not query_row_mapping:
        return {}

    row_boosts = {}
    query_lower = query.lower()
    query_words = set(query_lower.split())

    for past_query, data in query_row_mapping.items():
        past_words = set(past_query.lower().split())
        # Calculate word overlap between current query and past query
        overlap = len(query_words & past_words)
        if overlap > 0:
            similarity = overlap / max(len(query_words), len(past_words))
            # Boost rows based on similarity and feedback score
            for row_idx in data.get('good_rows', []):
                row_idx = int(row_idx)
                if row_idx not in row_boosts:
                    row_boosts[row_idx] = 0
                row_boosts[row_idx] += similarity * data.get('score', 1)
            # Penalize bad rows
            for row_idx in data.get('bad_rows', []):
                row_idx = int(row_idx)
                if row_idx not in row_boosts:
                    row_boosts[row_idx] = 0
                row_boosts[row_idx] -= similarity * data.get('score', 1) * 0.5

    return row_boosts


# Page config
st.set_page_config(
    page_title="Institutional AUM Dashboard",
    page_icon="📊",
    layout="wide"
)

# Initialize session state for persisting results
if 'last_query' not in st.session_state:
    st.session_state.last_query = None
if 'last_result_df' not in st.session_state:
    st.session_state.last_result_df = None
if 'last_message' not in st.session_state:
    st.session_state.last_message = None
if 'feedback_given' not in st.session_state:
    st.session_state.feedback_given = False
if 'last_row_indices' not in st.session_state:
    st.session_state.last_row_indices = []
if 'last_chart' not in st.session_state:
    st.session_state.last_chart = None

# Initialize suggestions in session state
if 'suggestions' not in st.session_state:
    st.session_state.suggestions = []

# Function to update suggestions based on typing
def update_suggestions():
    query = st.session_state.get('query_input', '')
    if query:
        first_word = query.split()[0].lower()
        # Common natural language query starters
        all_suggestions = [
            "find companies", "find records", "find accounts", "find portfolios", "find clients",
            "filter by", "filter records", "filter companies", "filter accounts", "filter portfolios",
            "show all companies", "show top", "show bottom", "show records", "show accounts",
            "list companies", "list accounts", "list portfolios", "list records",
            "top 10 by", "top 5 companies", "top 10 accounts", "top 20 portfolios",
            "bottom 5 by", "bottom 10 companies", "bottom 5 accounts",
            "companies starting with", "companies ending with", "records where",
            "sum of", "total", "average", "count", "maximum", "minimum",
            "compare regions", "compare portfolios", "compare companies",
            "what is the total", "how many", "which company has",
            "pie chart", "bar chart", "line chart", "scatter plot", "histogram"
        ]

        # Filter suggestions based on first word
        st.session_state.suggestions = [s for s in all_suggestions if s.startswith(first_word)]
    else:
        st.session_state.suggestions = []

# Load data
with st.spinner("Loading data..."):
    vectors, df, vectorizer = get_cached_vectors()

# Column definitions
numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()


def get_company_column(dataframe, categorical_columns):
    """Best-effort detection of the company *name* column.

    Prefers EDL_Company_nm style columns, then other 'company' + ('name'/'nm') columns.
    Avoids ID/key columns so prefix searches don't hit unrelated identifiers.
    """
    if dataframe is None or dataframe.empty:
        return None

    cols = list(dataframe.columns)

    def is_id_like(col: str) -> bool:
        cl = col.lower()
        return (
            'key' in cl
            or cl.endswith('_id')
            or cl.endswith('id')
            or cl.endswith('_key')
            or cl in {'id', 'key'}
        )

    # 1) Strong preference: exact / common naming
    preferred_patterns = [
        r'^edl_company_nm$',
        r'^edl_company_name$',
        r'^company_nm$',
        r'^company_name$',
    ]
    for c in cols:
        if c in categorical_columns and not is_id_like(c):
            cl = c.lower()
            if any(re.match(p, cl) for p in preferred_patterns):
                return c

    # 2) Company + (name/nm)
    for c in cols:
        if c in categorical_columns and not is_id_like(c):
            cl = c.lower()
            if 'company' in cl and ('name' in cl or cl.endswith('_nm') or '_nm_' in cl):
                return c

    # 3) Any company column that's not id-like
    for c in cols:
        if c in categorical_columns and not is_id_like(c):
            if 'company' in c.lower():
                return c

    return None


# Helper function: Reorder columns - EDL_Company_nm first, Portfolio_Group_nm second, priority columns next, keys at end
def reorder_columns(dataframe, priority_cols=None):
    if dataframe is None or dataframe.empty:
        return dataframe

    cols = list(dataframe.columns)

    # Find EDL_Company_nm column
    company_col = None
    for col in cols:
        if 'edl_company_nm' in col.lower():
            company_col = col
            break

    # Find Portfolio_Group_nm column
    portfolio_col = None
    for col in cols:
        if 'portfolio_group_nm' in col.lower():
            portfolio_col = col
            break

    # Find all key and id columns (columns containing 'key' or 'id')
    key_id_cols = [col for col in cols if 'key' in col.lower() or '_id' in col.lower() or col.lower().endswith('id')]

    # Remove special columns from their current positions
    if company_col and company_col in cols:
        cols.remove(company_col)
    if portfolio_col and portfolio_col in cols:
        cols.remove(portfolio_col)
    for col in key_id_cols:
        if col in cols:
            cols.remove(col)

    # Handle priority columns
    valid_priority_cols = []
    if priority_cols:
        for col in priority_cols:
            if col and col in dataframe.columns:
                # If it's in cols, remove it (it might be there)
                if col in cols:
                    cols.remove(col)
                # If it matches company or portfolio, we skip it here as it will be added at the start
                # except if we want to ensure it's not removed if it was company/portfolio?
                # company_col and portfolio_col are already removed from cols.
                if col != company_col and col != portfolio_col and col not in key_id_cols:
                    if col not in valid_priority_cols:
                        valid_priority_cols.append(col)

    # Build final order: EDL_Company_nm, Portfolio_Group_nm, Priority Cols, other cols, keys/ids at end
    final_cols = []
    if company_col:
        final_cols.append(company_col)
    if portfolio_col:
        final_cols.append(portfolio_col)

    final_cols.extend(valid_priority_cols)
    final_cols.extend(cols)
    final_cols.extend(key_id_cols)

    # Only return columns that exist
    valid_cols = [c for c in final_cols if c in dataframe.columns]
    return dataframe[valid_cols]


# Comprehensive chart creation function supporting all chart types
def create_advanced_chart(result_df, chart_type, query_lower, numeric_cols, categorical_cols, aum_col=None):
    """
    Create various chart types based on the chart_type parameter.
    Supports: line, bar, horizontal_bar, pie, scatter, histogram, area, stacked_area,
    box, violin, swarm, strip, distplot, kde, ecdf, pairplot, jointplot, heatmap,
    correlation, bubble, hexbin, andrews, parallel
    """
    if result_df.empty:
        return None

    # Find appropriate columns
    group_col = None

    # If the user explicitly asks for companies, prefer the company column if present.
    company_col = get_company_column(result_df, result_df.columns.tolist())

    wants_company_grouping = any(
        kw in (query_lower or '') for kw in ['company', 'companies', 'edl_company_nm']
    )

    if wants_company_grouping and company_col:
        group_col = company_col

    # Otherwise, keep existing behavior: prefer portfolio group if present, then first categorical.
    if not group_col:
        for gc in result_df.columns:
            if 'portfolio' in gc.lower() and 'group' in gc.lower():
                group_col = gc
                break
    if not group_col:
        for gc in result_df.columns:
            if gc in categorical_cols:
                group_col = gc
                break

    val_col = aum_col if aum_col and aum_col in result_df.columns else (numeric_cols[0] if numeric_cols else None)

    # Get available numeric columns for multi-variable charts
    available_numeric = [c for c in numeric_cols if c in result_df.columns]
    available_categorical = [c for c in categorical_cols if c in result_df.columns]

    try:
        # LINE CHART
        if chart_type == 'line':
            if group_col and val_col:
                chart_df = result_df.groupby(group_col)[val_col].sum().reset_index()
                chart_df = chart_df.sort_values(val_col, ascending=False).head(20)
                fig = px.line(chart_df, x=group_col, y=val_col, title=f"Line Chart: {val_col} by {group_col}",
                              markers=True)
                fig.update_layout(xaxis_tickangle=-45)
                return fig

        # BAR CHART
        elif chart_type == 'bar':
            if group_col and val_col:
                chart_df = result_df.groupby(group_col)[val_col].sum().reset_index()
                chart_df = chart_df.sort_values(val_col, ascending=False).head(20)
                fig = px.bar(chart_df, x=group_col, y=val_col, title=f"Bar Chart: {val_col} by {group_col}")
                fig.update_layout(xaxis_tickangle=-45)
                return fig

        # HORIZONTAL BAR CHART
        elif chart_type == 'horizontal_bar':
            if group_col and val_col:
                chart_df = result_df.groupby(group_col)[val_col].sum().reset_index()
                chart_df = chart_df.sort_values(val_col, ascending=True).tail(20)
                fig = px.bar(chart_df, y=group_col, x=val_col, orientation='h',
                             title=f"Horizontal Bar Chart: {val_col} by {group_col}")
                return fig

        # PIE CHART
        elif chart_type == 'pie':
            if group_col and val_col:
                chart_df = result_df.groupby(group_col)[val_col].sum().reset_index()
                chart_df = chart_df.sort_values(val_col, ascending=False).head(10)
                fig = px.pie(chart_df, values=val_col, names=group_col, title=f"Pie Chart: {val_col} by {group_col}")
                return fig

        # SCATTER PLOT
        elif chart_type == 'scatter':
            if len(available_numeric) >= 2:
                x_col, y_col = available_numeric[0], available_numeric[1]
                color_col = available_categorical[0] if available_categorical else None
                fig = px.scatter(result_df.head(500), x=x_col, y=y_col, color=color_col,
                                 title=f"Scatter Plot: {x_col} vs {y_col}")
                return fig
            elif group_col and val_col:
                fig = px.scatter(result_df.head(500), x=group_col, y=val_col,
                                 title=f"Scatter Plot: {val_col} by {group_col}")
                return fig

        # HISTOGRAM
        elif chart_type == 'histogram':
            if val_col:
                fig = px.histogram(result_df, x=val_col, nbins=30, title=f"Histogram: Distribution of {val_col}")
                return fig

        # AREA CHART
        elif chart_type == 'area':
            if group_col and val_col:
                chart_df = result_df.groupby(group_col)[val_col].sum().reset_index()
                chart_df = chart_df.sort_values(val_col, ascending=False).head(20)
                fig = px.area(chart_df, x=group_col, y=val_col, title=f"Area Chart: {val_col} by {group_col}")
                fig.update_layout(xaxis_tickangle=-45)
                return fig

        # STACKED AREA CHART
        elif chart_type == 'stacked_area':
            if len(available_categorical) >= 2 and val_col:
                chart_df = result_df.groupby([available_categorical[0], available_categorical[1]])[
                    val_col].sum().reset_index()
                chart_df = chart_df.head(100)
                fig = px.area(chart_df, x=available_categorical[0], y=val_col, color=available_categorical[1],
                              title=f"Stacked Area Chart: {val_col}")
                fig.update_layout(xaxis_tickangle=-45)
                return fig
            elif group_col and val_col:
                return create_advanced_chart(result_df, 'area', query_lower, numeric_cols, categorical_cols, aum_col)

        # BOX PLOT
        elif chart_type == 'box':
            if val_col:
                color_col = available_categorical[0] if available_categorical else None
                fig = px.box(result_df.head(1000), y=val_col, x=color_col, color=color_col,
                             title=f"Box Plot: Distribution of {val_col}")
                fig.update_layout(xaxis_tickangle=-45)
                return fig

        # VIOLIN PLOT
        elif chart_type == 'violin':
            if val_col:
                color_col = available_categorical[0] if available_categorical else None
                fig = px.violin(result_df.head(1000), y=val_col, x=color_col, color=color_col, box=True,
                                title=f"Violin Plot: Distribution of {val_col}")
                fig.update_layout(xaxis_tickangle=-45)
                return fig

        # STRIP PLOT
        elif chart_type == 'strip':
            if val_col:
                color_col = available_categorical[0] if available_categorical else None
                fig = px.strip(result_df.head(500), y=val_col, x=color_col, color=color_col,
                               title=f"Strip Plot: {val_col}")
                fig.update_layout(xaxis_tickangle=-45)
                return fig

        # SWARM PLOT (using strip with jitter as plotly doesn't have native swarm)
        elif chart_type == 'swarm':
            if val_col:
                color_col = available_categorical[0] if available_categorical else None
                # Use matplotlib/seaborn for true swarm plot
                fig_mpl, ax = plt.subplots(figsize=(10, 6))
                plot_df = result_df.head(200).copy()
                if color_col:
                    sns.swarmplot(data=plot_df, x=color_col, y=val_col, ax=ax)
                    plt.xticks(rotation=45, ha='right')
                else:
                    sns.swarmplot(data=plot_df, y=val_col, ax=ax)
                ax.set_title(f"Swarm Plot: {val_col}")
                plt.tight_layout()
                return fig_mpl

        # DISTRIBUTION PLOT (distplot/histplot/kdeplot combined)
        elif chart_type == 'distplot':
            if val_col:
                fig_mpl, ax = plt.subplots(figsize=(10, 6))
                sns.histplot(data=result_df, x=val_col, kde=True, ax=ax)
                ax.set_title(f"Distribution Plot: {val_col}")
                plt.tight_layout()
                return fig_mpl

        # KDE PLOT (Kernel Density Estimate)
        elif chart_type == 'kde':
            if val_col:
                fig_mpl, ax = plt.subplots(figsize=(10, 6))
                color_col = available_categorical[0] if available_categorical else None
                if color_col:
                    for cat in result_df[color_col].dropna().unique()[:10]:
                        subset = result_df[result_df[color_col] == cat]
                        sns.kdeplot(data=subset, x=val_col, label=str(cat), ax=ax)
                    ax.legend()
                else:
                    sns.kdeplot(data=result_df, x=val_col, ax=ax)
                ax.set_title(f"KDE Plot: Density of {val_col}")
                plt.tight_layout()
                return fig_mpl

        # ECDF PLOT (Empirical Cumulative Distribution)
        elif chart_type == 'ecdf':
            if val_col:
                color_col = available_categorical[0] if available_categorical else None
                fig = px.ecdf(result_df, x=val_col, color=color_col,
                              title=f"ECDF Plot: Cumulative Distribution of {val_col}")
                return fig

        # PAIR PLOT
        elif chart_type == 'pairplot':
            if len(available_numeric) >= 2:
                plot_cols = available_numeric[:4]  # Limit to 4 columns for readability
                color_col = available_categorical[0] if available_categorical else None
                plot_df = result_df[plot_cols + ([color_col] if color_col else [])].dropna().head(200)
                fig = px.scatter_matrix(plot_df, dimensions=plot_cols, color=color_col,
                                        title="Pair Plot: Numeric Variable Relationships")
                return fig

        # JOINT PLOT
        elif chart_type == 'jointplot':
            if len(available_numeric) >= 2:
                x_col, y_col = available_numeric[0], available_numeric[1]
                fig_mpl = sns.jointplot(data=result_df.head(500), x=x_col, y=y_col, kind='scatter')
                fig_mpl.fig.suptitle(f"Joint Plot: {x_col} vs {y_col}", y=1.02)
                return fig_mpl.fig

        # HEATMAP
        elif chart_type == 'heatmap':
            if len(available_categorical) >= 2 and val_col:
                pivot_df = result_df.pivot_table(values=val_col,
                                                 index=available_categorical[0],
                                                 columns=available_categorical[1],
                                                 aggfunc='sum').fillna(0)
                pivot_df = pivot_df.iloc[:15, :15]  # Limit size
                fig = px.imshow(pivot_df,
                                title=f"Heatmap: {val_col} by {available_categorical[0]} and {available_categorical[1]}",
                                aspect='auto', color_continuous_scale='Viridis')
                return fig
            elif len(available_numeric) >= 2:
                # Fallback to correlation heatmap
                return create_advanced_chart(result_df, 'correlation', query_lower, numeric_cols, categorical_cols,
                                             aum_col)

        # CORRELATION MATRIX HEATMAP
        elif chart_type == 'correlation':
            if len(available_numeric) >= 2:
                corr_cols = available_numeric[:10]  # Limit columns
                corr_matrix = result_df[corr_cols].corr()
                fig = px.imshow(corr_matrix, title="Correlation Matrix Heatmap",
                                text_auto='.2f', aspect='auto', color_continuous_scale='RdBu_r',
                                zmin=-1, zmax=1)
                return fig

        # BUBBLE CHART
        elif chart_type == 'bubble':
            if len(available_numeric) >= 2:
                x_col, y_col = available_numeric[0], available_numeric[1]
                size_col = available_numeric[2] if len(available_numeric) >= 3 else available_numeric[0]
                color_col = available_categorical[0] if available_categorical else None
                plot_df = result_df.head(200).copy()
                # Ensure positive sizes
                plot_df[size_col] = plot_df[size_col].abs()
                fig = px.scatter(plot_df, x=x_col, y=y_col, size=size_col, color=color_col,
                                 title=f"Bubble Chart: {x_col} vs {y_col} (size: {size_col})",
                                 hover_name=color_col)
                return fig

        # HEXBIN PLOT
        elif chart_type == 'hexbin':
            if len(available_numeric) >= 2:
                x_col, y_col = available_numeric[0], available_numeric[1]
                fig = px.density_heatmap(result_df.head(1000), x=x_col, y=y_col,
                                         title=f"Hexbin Plot: {x_col} vs {y_col}",
                                         nbinsx=20, nbinsy=20, color_continuous_scale='Viridis')
                return fig

        # ANDREWS CURVES
        elif chart_type == 'andrews':
            if len(available_numeric) >= 2 and available_categorical:
                plot_cols = available_numeric[:5]
                color_col = available_categorical[0]
                plot_df = result_df[plot_cols + [color_col]].dropna().head(100)
                # Limit unique categories
                top_cats = plot_df[color_col].value_counts().head(5).index
                plot_df = plot_df[plot_df[color_col].isin(top_cats)]
                fig_mpl, ax = plt.subplots(figsize=(10, 6))
                andrews_curves(plot_df, color_col, ax=ax)
                ax.set_title(f"Andrews Curves by {color_col}")
                plt.tight_layout()
                return fig_mpl

        # PARALLEL COORDINATES
        elif chart_type == 'parallel':
            if len(available_numeric) >= 2:
                plot_cols = available_numeric[:6]
                color_col = available_categorical[0] if available_categorical else None
                plot_df = result_df[plot_cols + ([color_col] if color_col else [])].dropna().head(100)
                if color_col:
                    fig = px.parallel_coordinates(plot_df, dimensions=plot_cols, color=color_col,
                                                  title="Parallel Coordinates Plot")
                else:
                    fig = px.parallel_coordinates(plot_df, dimensions=plot_cols,
                                                  title="Parallel Coordinates Plot")
                return fig

        # Default fallback - bar chart
        else:
            if group_col and val_col:
                chart_df = result_df.groupby(group_col)[val_col].sum().reset_index()
                chart_df = chart_df.sort_values(val_col, ascending=False).head(20)
                fig = px.bar(chart_df, x=group_col, y=val_col, title=f"{val_col} by {group_col}")
                fig.update_layout(xaxis_tickangle=-45)
                return fig

    except Exception as e:
        st.warning(f"Could not create {chart_type} chart: {str(e)}")
        return None

    return None


# Function to detect chart type from query
def detect_chart_type(query_lower):
    """Detect the chart type requested in the query."""
    chart_keywords = {
        'line': ['line chart', 'line graph', 'line plot', 'linechart'],
        'bar': ['bar chart', 'bar graph', 'barchart', 'column chart'],
        'horizontal_bar': ['horizontal bar', 'hbar', 'horizontal chart'],
        'pie': ['pie chart', 'pie graph', 'piechart'],
        'scatter': ['scatter plot', 'scatter chart', 'scatterplot'],
        'histogram': ['histogram', 'hist', 'frequency distribution'],
        'area': ['area chart', 'area graph', 'areachart'],
        'stacked_area': ['stacked area', 'stacked chart'],
        'box': ['box plot', 'boxplot', 'box and whisker'],
        'violin': ['violin plot', 'violinplot', 'violin chart'],
        'swarm': ['swarm plot', 'swarmplot', 'beeswarm'],
        'strip': ['strip plot', 'stripplot', 'jitter plot'],
        'distplot': ['distribution plot', 'distplot', 'histplot'],
        'kde': ['kde', 'kernel density', 'density plot', 'kdeplot'],
        'ecdf': ['ecdf', 'cumulative distribution', 'empirical cumulative'],
        'pairplot': ['pair plot', 'pairplot', 'pairs'],
        'jointplot': ['joint plot', 'jointplot', 'joint distribution'],
        'heatmap': ['heatmap', 'heat map'],
        'correlation': ['correlation matrix', 'correlation heatmap', 'corr matrix', 'correlations'],
        'bubble': ['bubble chart', 'bubble plot', 'bubbles'],
        'hexbin': ['hexbin', 'hex bin', 'hexagonal bin'],
        'andrews': ['andrews curve', 'andrews plot'],
        'parallel': ['parallel coordinates', 'parallel plot', 'parallel chart'],
    }

    for chart_type, keywords in chart_keywords.items():
        for keyword in keywords:
            if keyword in query_lower:
                return chart_type

    # Generic chart detection
    if any(word in query_lower for word in ['chart', 'graph', 'plot', 'visualize', 'visualization']):
        return 'bar'  # Default to bar chart

    return None


# Title
st.markdown("<h1 style='text-align: center;'>📊 Institutional AUM Data Explorer</h1>", unsafe_allow_html=True)

# Show LLM status in sidebar
with st.sidebar:
    st.markdown("### ⚙️ System Status")
    if OLLAMA_AVAILABLE:
        try:
            models = ollama.list().get('models', [])
            model_found = False
            for model in models:
                name = model.get('name', '')
                base = name.split(':', 1)[0]
                if OLLAMA_MODEL in {name, base}:
                    model_found = True
                    break

            if model_found:
                st.success(f"🤖 LLM: Ollama Connected ({OLLAMA_MODEL})")
            else:
                st.warning(
                    f"🤖 LLM running, but model '{OLLAMA_MODEL}' not found. "
                    f"Run `ollama pull {OLLAMA_MODEL}` to install."
                )
        except Exception:
            st.warning("🤖 LLM: Ollama not running")
    else:
        st.info("🔍 Using semantic search")
    st.markdown(f"📊 Data: {len(df)} rows loaded")
    st.markdown(f"📋 Columns: {len(df.columns)}")
    st.markdown("---")

    # 🔎 Quick Filters (new convenience, keep or remove as you like)
    st.markdown("### 🔎 Quick Filters")
    q1 = st.button("📅 AUM on 2025-04-30")
    q2 = st.button("🌲 MIM Timber & Agriculture Template")
    q3 = st.button("🔒 Private Markets = Y")
    q4 = st.button("💵 Original Currency = USD")
    q5 = st.button("🗺️ Region ID = NF")
    q6 = st.button("🏷️ List all companies")

    st.markdown("---")
    st.markdown("### 💬 Natural Language Search")
    st.markdown("Ask anything about your data!")
    st.markdown("")
    with st.expander("📝 Example Queries"):
        st.markdown("""
        **Search & Filter:**
        - Show all companies
        - Find companies starting with "John"
        - List accounts from New York
        - Records where AUM > 1000000

        **Analytics:**
        - Top 10 by AUM
        - Bottom 5 portfolios
        - Total AUM
        - Average revenue
        - Count of records

        **Comparisons:**
        - Compare regions by AUM
        - Which company has highest AUM?

        **Any question in plain English!**
        """)

    with st.expander("📈 24+ Chart Types"):
        st.markdown("""
        - Line, Bar, Horizontal Bar
        - Pie, Scatter, Histogram
        - Area, Stacked Area
        - Box, Violin, Swarm, Strip
        - Distribution, KDE, ECDF
        - Pair Plot, Joint Plot
        - Heatmap, Correlation Matrix
        - Bubble, Hexbin
        - Andrews Curves, Parallel Coordinates
        """)

    with st.expander("📊 Available Columns"):
        for col in df.columns:
            st.markdown(f"• {col}")

# Query input
col1, col2, col3 = st.columns([1, 3, 1])
with col2:
    query = st.text_area("🔍 Ask anything about your data:", height=100,
                         placeholder="Examples:\n• Companies starting with 'John'\n• Show records where AUM > 1000000\n• Top 10 accounts by revenue\n• What is the total AUM?\n• Compare portfolios by region with a pie chart\n\n💡 Type 'help' for all examples and chart types!",
                         key='query_input', on_change=update_suggestions)

    # If a sidebar quick filter was clicked, inject its query and auto-run.
    quick_query = None
    if 'q1' in globals() and q1:
        quick_query = "Show me all AUM records for April 30, 2025"
    elif 'q2' in globals() and q2:
        quick_query = "What entries come from the MIM Timber & Agriculture Template source?"
    elif 'q3' in globals() and q3:
        quick_query = "Which records are marked as private markets?"
    elif 'q4' in globals() and q4:
        quick_query = "Show all accounts where the original currency is USD"
    elif 'q5' in globals() and q5:
        quick_query = "Find all entries where the region ID is NF"
    elif 'q6' in globals() and q6:
        quick_query = "Show all companies"

    if quick_query:
        query = quick_query

    submit_button = st.button("🚀 Submit Query", type="primary", use_container_width=True) or bool(quick_query)

    # Display suggestions if available
    if st.session_state.suggestions:
        st.markdown("**💡 Suggestions:**")
        cols = st.columns(min(len(st.session_state.suggestions), 3))
        for i, sug in enumerate(st.session_state.suggestions[:3]):
            with cols[i]:
                if st.button(sug, key=f"sug_{i}"):
                    st.session_state.query_input = sug
                    st.rerun()

st.markdown("---")

# Query processing using LLM + semantic search
if query and submit_button:
    st.session_state.feedback_given = False  # Reset feedback state for new query
    st.session_state.last_query = query
    st.session_state.last_chart = None  # Reset chart
    query_lower = query.lower()

    # Initialize priority columns for better result visibility
    priority_cols = []

    # Find AUM column first
    aum_col = None
    for col in numeric_cols:
        if 'aum' in col.lower():
            aum_col = col
            break
    if not aum_col and numeric_cols:
        aum_col = numeric_cols[0]

    # Try LLM first for natural language understanding
    llm_response = None
    llm_error = None
    if OLLAMA_AVAILABLE:
        df_info = f"Total rows: {len(df)}, Numeric columns: {numeric_cols[:5]}, Categorical columns: {categorical_cols[:5]}"
        llm_raw_response = ask_llm(query, df_info, list(df.columns)[:15])
        if isinstance(llm_raw_response, dict) and llm_raw_response.get('_error'):
            llm_error = llm_raw_response
        else:
            llm_response = llm_raw_response

    if llm_error:
        error_message = llm_error.get('details', 'Unknown LLM error')
        if llm_error.get('_error') == 'model_not_found':
            error_message = (
                f"Ollama model '{OLLAMA_MODEL}' is missing. Run `ollama pull {OLLAMA_MODEL}` in a terminal."
            )
        st.sidebar.warning(f"🤖 LLM issue: {error_message}")

    if llm_response:
        # LLM understood the query - process based on intent
        st.sidebar.success("✨ Query processed by LLM")
        intent = llm_response.get('intent', 'general')
        n = llm_response.get('n', 10)
        sort_col = llm_response.get('sort_column') or aum_col
        sort_order = llm_response.get('sort_order', 'desc')
        chart_type = llm_response.get('chart_type', 'none')
        filter_col = llm_response.get('filter_column')
        filter_op = llm_response.get('filter_operator', 'contains')
        filter_val = llm_response.get('filter_value')
        filter_val2 = llm_response.get('filter_value2')
        search_col = llm_response.get('search_column')
        search_val = llm_response.get('search_value')
        search_type = llm_response.get('search_type', 'contains')
        agg_func = llm_response.get('aggregate_function')
        agg_col = llm_response.get('aggregate_column') or aum_col
        group_by = llm_response.get('group_by')
        answer = llm_response.get('answer', '')

        result_df = df.copy()


        # Helper function to find matching column
        def find_column(col_name, prefer_type='any'):
            if not col_name:
                return None
            # Exact match
            if col_name in df.columns:
                return col_name
            # Case-insensitive match
            for c in df.columns:
                if c.lower() == col_name.lower():
                    return c
            # Partial match
            for c in df.columns:
                if col_name.lower() in c.lower():
                    if prefer_type == 'numeric' and c in numeric_cols:
                        return c
                    elif prefer_type == 'categorical' and c in categorical_cols:
                        return c
                    elif prefer_type == 'any':
                        return c
            return None

        # Identify interesting columns for display priority
        priority_cols = []
        if sort_col:
            c = find_column(sort_col)
            if c: priority_cols.append(c)
        if agg_col:
            c = find_column(agg_col)
            if c and c not in priority_cols: priority_cols.append(c)
        if filter_col:
            c = find_column(filter_col)
            if c and c not in priority_cols: priority_cols.append(c)
        if search_col:
            c = find_column(search_col)
            if c and c not in priority_cols: priority_cols.append(c)
        if group_by:
            c = find_column(group_by)
            if c and c not in priority_cols: priority_cols.append(c)


        # Apply advanced filter if specified
        if filter_col and filter_val:
            actual_filter_col = find_column(filter_col)
            if actual_filter_col:
                try:
                    if filter_op == 'greater_than':
                        filter_num = float(str(filter_val).replace(',', '').replace('$', ''))
                        mask = result_df[actual_filter_col] > filter_num
                    elif filter_op == 'less_than':
                        filter_num = float(str(filter_val).replace(',', '').replace('$', ''))
                        mask = result_df[actual_filter_col] < filter_num
                    elif filter_op == 'between' and filter_val2:
                        val1 = float(str(filter_val).replace(',', '').replace('$', ''))
                        val2 = float(str(filter_val2).replace(',', '').replace('$', ''))
                        mask = (result_df[actual_filter_col] >= val1) & (result_df[actual_filter_col] <= val2)
                    elif filter_op == 'equals':
                        mask = result_df[actual_filter_col].astype(str).str.lower() == str(filter_val).lower()
                    elif filter_op == 'not_equals':
                        mask = result_df[actual_filter_col].astype(str).str.lower() != str(filter_val).lower()
                    elif filter_op == 'starts_with':
                        mask = result_df[actual_filter_col].astype(str).str.lower().str.startswith(
                            str(filter_val).lower())
                    elif filter_op == 'ends_with':
                        mask = result_df[actual_filter_col].astype(str).str.lower().str.endswith(
                            str(filter_val).lower())
                    else:  # contains
                        mask = result_df[actual_filter_col].astype(str).str.contains(str(filter_val), case=False,
                                                                                     na=False)
                    result_df = result_df[mask].copy()
                except (ValueError, TypeError):
                    # If conversion fails, try string contains
                    mask = result_df[actual_filter_col].astype(str).str.contains(str(filter_val), case=False, na=False)
                    result_df = result_df[mask].copy()

        # Handle different intents
        if intent == 'show_all':
            result_df = result_df.head(n) if len(result_df) > n else result_df
            st.session_state.last_message = f"✅ Showing {len(result_df)} records"
            st.session_state.last_result_df = reorder_columns(result_df)
            st.session_state.last_row_indices = result_df.index.tolist()

        elif intent == 'search' and search_val:
            # Find the search column
            actual_search_col = find_column(search_col, 'categorical')
            if not actual_search_col:
                for col in categorical_cols:
                    if 'company' in col.lower() or 'name' in col.lower():
                        actual_search_col = col
                        break
                if not actual_search_col and categorical_cols:
                    actual_search_col = categorical_cols[0]

            if actual_search_col:
                search_val_lower = str(search_val).lower()
                col_values = result_df[actual_search_col].astype(str).str.lower()

                if search_type == 'starts_with':
                    mask = col_values.str.startswith(search_val_lower)
                    search_desc = f"starting with '{search_val}'"
                elif search_type == 'ends_with':
                    mask = col_values.str.endswith(search_val_lower)
                    search_desc = f"ending with '{search_val}'"
                elif search_type == 'exact':
                    mask = col_values == search_val_lower
                    search_desc = f"exactly matching '{search_val}'"
                else:
                    mask = col_values.str.contains(search_val_lower, na=False, regex=False)
                    search_desc = f"containing '{search_val}'"

                if mask.any():
                    result_df = result_df[mask].copy()
                    st.session_state.last_message = f"✅ Found {len(result_df)} records {search_desc} in {actual_search_col}"
                    st.session_state.last_result_df = reorder_columns(result_df)
                    st.session_state.last_row_indices = result_df.index.tolist()
                else:
                    st.session_state.last_message = f"⚠️ No records found {search_desc} in {actual_search_col}"
                    st.session_state.last_result_df = None
                    st.session_state.last_row_indices = []

        elif intent == 'filter':
            if len(result_df) > 0:
                result_df = result_df.head(n) if len(result_df) > n else result_df
                st.session_state.last_message = f"✅ Found {len(result_df)} records matching your filter"
                st.session_state.last_result_df = reorder_columns(result_df, priority_cols)
                st.session_state.last_row_indices = result_df.index.tolist()
            else:
                st.session_state.last_message = f"⚠️ No records match your filter criteria"
                st.session_state.last_result_df = None
                st.session_state.last_row_indices = []

        elif intent == 'top':
            actual_sort_col = find_column(sort_col, 'numeric')
            if actual_sort_col and actual_sort_col in result_df.columns:
                result_df = result_df.nlargest(n, actual_sort_col)
                st.session_state.last_message = f"✅ Top {n} by '{actual_sort_col}'"
                st.session_state.last_result_df = reorder_columns(result_df, priority_cols)
                st.session_state.last_row_indices = result_df.index.tolist()

        elif intent == 'bottom':
            actual_sort_col = find_column(sort_col, 'numeric')
            if actual_sort_col and actual_sort_col in result_df.columns:
                result_df = result_df.nsmallest(n, actual_sort_col)
                st.session_state.last_message = f"✅ Bottom {n} by '{actual_sort_col}'"
                st.session_state.last_result_df = reorder_columns(result_df, priority_cols)
                st.session_state.last_row_indices = result_df.index.tolist()

        elif intent == 'aggregate':
            actual_agg_col = find_column(agg_col, 'numeric')
            actual_group_col = find_column(group_by, 'categorical')

            if actual_agg_col and actual_agg_col in result_df.columns:
                if actual_group_col:
                    # Group by aggregation
                    if agg_func == 'sum':
                        agg_result = result_df.groupby(actual_group_col)[actual_agg_col].sum().reset_index()
                    elif agg_func == 'average':
                        agg_result = result_df.groupby(actual_group_col)[actual_agg_col].mean().reset_index()
                    elif agg_func == 'count':
                        agg_result = result_df.groupby(actual_group_col)[actual_agg_col].count().reset_index()
                    elif agg_func == 'min':
                        agg_result = result_df.groupby(actual_group_col)[actual_agg_col].min().reset_index()
                    elif agg_func == 'max':
                        agg_result = result_df.groupby(actual_group_col)[actual_agg_col].max().reset_index()
                    else:
                        agg_result = result_df.groupby(actual_group_col)[actual_agg_col].sum().reset_index()

                    agg_result = agg_result.sort_values(actual_agg_col, ascending=False).head(20)
                    st.session_state.last_message = f"✅ {agg_func.title() if agg_func else 'Sum'} of {actual_agg_col} by {actual_group_col}"
                    st.session_state.last_result_df = agg_result
                    st.session_state.last_row_indices = []
                else:
                    # Simple aggregation
                    if agg_func == 'sum':
                        value = result_df[actual_agg_col].sum()
                    elif agg_func == 'average':
                        value = result_df[actual_agg_col].mean()
                    elif agg_func == 'count':
                        value = len(result_df)
                    elif agg_func == 'min':
                        value = result_df[actual_agg_col].min()
                    elif agg_func == 'max':
                        value = result_df[actual_agg_col].max()
                    elif agg_func == 'median':
                        value = result_df[actual_agg_col].median()
                    else:
                        value = result_df[actual_agg_col].sum()

                    st.session_state.last_message = f"✅ {agg_func.title() if agg_func else 'Total'} {actual_agg_col}: {value:,.2f}"
                    if answer:
                        st.session_state.last_message += f"\n\n💬 {answer}"
                    st.session_state.last_result_df = None

        elif intent in ['compare', 'distribution', 'correlation', 'trend']:
            # These are analysis intents - show grouped data or stats
            actual_group_col = find_column(group_by, 'categorical')
            actual_val_col = find_column(sort_col, 'numeric') or aum_col

            if actual_group_col and actual_val_col:
                agg_result = result_df.groupby(actual_group_col)[actual_val_col].agg(
                    ['sum', 'mean', 'count']).reset_index()
                agg_result.columns = [actual_group_col, 'Total', 'Average', 'Count']
                agg_result = agg_result.sort_values('Total', ascending=False).head(20)
                st.session_state.last_message = f"✅ Analysis of {actual_val_col} by {actual_group_col}"
                st.session_state.last_result_df = agg_result
                st.session_state.last_row_indices = []
            else:
                result_df = result_df.head(n)
                st.session_state.last_message = f"✅ Showing {len(result_df)} results"
                st.session_state.last_result_df = reorder_columns(result_df, priority_cols)

        elif intent == 'question':
            # User asked a question - provide answer with data if relevant
            if answer:
                st.session_state.last_message = f"💬 {answer}"
            else:
                st.session_state.last_message = f"✅ Based on {len(result_df)} records in the data"
            if len(result_df) <= n:
                st.session_state.last_result_df = reorder_columns(result_df, priority_cols)
            else:
                st.session_state.last_result_df = None

        else:  # general, chart, or unknown intent
            result_df = result_df.head(n) if len(result_df) > n else result_df
            if answer:
                st.session_state.last_message = f"💬 {answer}"
            else:
                st.session_state.last_message = f"✅ Showing {len(result_df)} results"
            st.session_state.last_result_df = reorder_columns(result_df, priority_cols)
            st.session_state.last_row_indices = result_df.index.tolist()

        # Create chart if requested
        if chart_type and chart_type != 'none' and st.session_state.last_result_df is not None and len(result_df) > 0:
            fig = create_advanced_chart(result_df, chart_type, query_lower, numeric_cols, categorical_cols, aum_col)
            if fig is not None:
                st.session_state.last_chart = fig

    else:
        # Fall back to keyword-based processing if LLM not available or failed
        st.sidebar.info("🔍 Using keyword matching")
        # Extract number from query
        numbers = re.findall(r'\d+', query)
        if numbers:
            n = int(numbers[0])
        else:
            singular_patterns = ['largest account', 'biggest account', 'top account', 'highest account',
                                 'smallest account', 'lowest account', 'best account', 'worst account',
                                 'largest company', 'biggest company', 'top company', 'highest company',
                                 'the largest', 'the biggest', 'the top', 'the highest', 'the smallest', 'the lowest']
            if any(pattern in query_lower for pattern in singular_patterns):
                n = 1
            else:
                n = 10

        # Check if user wants a chart - expanded to detect all chart types
        chart_keywords_list = ['chart', 'bar', 'barchart', 'pie', 'piechart', 'line', 'linechart',
                               'scatter', 'graph', 'plot', 'visualize', 'visualization',
                               'histogram', 'area', 'box', 'boxplot', 'violin', 'swarm', 'strip',
                               'distribution', 'distplot', 'kde', 'density', 'ecdf', 'cumulative',
                               'pairplot', 'pair plot', 'jointplot', 'joint plot', 'heatmap',
                               'correlation', 'bubble', 'hexbin', 'andrews', 'parallel']
        wants_chart = any(word in query_lower for word in chart_keywords_list)
        detected_chart_type = detect_chart_type(query_lower)

        # Check if this is a data query (mentions data-related terms) vs conversational question
        data_terms = ['account', 'accounts', 'client', 'clients', 'company', 'companies', 'portfolio', 'portfolios',
                      'fund', 'funds', 'aum', 'revenue', 'asset', 'assets', 'record', 'records', 'data', 'show',
                      'list', 'find', 'get', 'display']
        is_data_query = any(term in query_lower for term in data_terms)

        # Check if this is a conversational/opinion question
        conversational_patterns = ['who is', 'what is', 'why is', 'how is', 'your mind', 'you think', 'your opinion',
                                   'do you', 'can you', 'would you', 'should i', 'what do you']
        is_conversational = any(pattern in query_lower for pattern in conversational_patterns)


        # Helper function to create chart from result dataframe using advanced chart types
        def create_chart(result_df, term="Data"):
            # Use detected chart type or default to bar
            chart_type = detected_chart_type if detected_chart_type else 'bar'
            return create_advanced_chart(result_df, chart_type, query_lower, numeric_cols, categorical_cols, aum_col)


        # Check for top/bottom queries FIRST (only if it's a data query, not conversational)
        top_keywords = ['top', 'highest', 'largest', 'best', 'most', 'biggest', 'greatest', 'maximum', 'max',
                        'leading', 'premier', 'major', 'dominant', 'primary', 'principal', 'chief', 'main',
                        'superior', 'supreme', 'foremost', 'first', 'number one', '#1', 'no.1', 'no 1',
                        'rich', 'richest', 'wealthy', 'wealthiest', 'profitable', 'successful', 'popular',
                        'high', 'higher', 'big', 'bigger', 'large', 'larger', 'great', 'greater',
                        'peak', 'pinnacle', 'elite', 'premium', 'prime', 'star', 'champion', 'winner']

        bottom_keywords = ['bottom', 'lowest', 'smallest', 'least', 'worst', 'minimum', 'min', 'tiniest',
                           'weakest', 'poorest', 'last', 'trailing', 'minor', 'minimal', 'negligible',
                           'low', 'lower', 'small', 'smaller', 'tiny', 'tinier', 'little', 'littlest',
                           'fewer', 'fewest', 'less', 'lesser', 'declining', 'failing', 'struggling',
                           'underperforming', 'lagging', 'losing', 'loser', 'worst-performing']

        if not is_conversational and is_data_query and any(word in query_lower for word in top_keywords):
            if aum_col:
                priority_cols = [aum_col]
                result_df = df.nlargest(n, aum_col)
                st.session_state.last_message = f"✅ Top {n} by '{aum_col}'"
                st.session_state.last_result_df = reorder_columns(result_df, priority_cols)
                if wants_chart:
                    st.session_state.last_chart = create_chart(result_df, f"Top {n}")
            else:
                result_df = df.head(n)
                st.session_state.last_message = f"✅ Showing first {n} records"
                st.session_state.last_result_df = reorder_columns(result_df, priority_cols)

        elif not is_conversational and is_data_query and any(word in query_lower for word in bottom_keywords):
            if aum_col:
                priority_cols = [aum_col]
                result_df = df.nsmallest(n, aum_col)
                st.session_state.last_message = f"✅ Bottom {n} by '{aum_col}'"
                st.session_state.last_result_df = reorder_columns(result_df, priority_cols)
                if wants_chart:
                    st.session_state.last_chart = create_chart(result_df, f"Bottom {n}")
            else:
                result_df = df.tail(n)
                st.session_state.last_message = f"✅ Showing last {n} records"
                st.session_state.last_result_df = reorder_columns(result_df, priority_cols)

        elif any(word in query_lower for word in ['sum', 'total']):
            if aum_col:
                st.session_state.last_message = f"✅ Total {aum_col}: {df[aum_col].sum():,.2f}"
                st.session_state.last_result_df = None

        elif any(word in query_lower for word in ['average', 'avg', 'mean']):
            if aum_col:
                st.session_state.last_message = f"✅ Average {aum_col}: {df[aum_col].mean():,.2f}"
                st.session_state.last_result_df = None

        elif re.search(r'\bcount\b', query_lower) or 'how many' in query_lower:
            st.session_state.last_message = f"✅ Total records: {len(df)}"
            st.session_state.last_result_df = None

        else:
            # Natural language search - be flexible and smart about finding data
            found_exact_match = False

            # --- Explicit company listing / prefix handlers (avoid semantic-search randomness) ---
            company_col = get_company_column(df, categorical_cols)

            # "show/list all companies" => distinct company names
            # Only trigger if it's a simple request, not asking for analytics/values
            has_numeric_col_mention = any(c.lower() in query_lower for c in numeric_cols if len(c) > 3)
            has_analytics_keywords = any(k in query_lower for k in ['by', 'sort', 'order', 'sum', 'average', 'count', 'total', 'aum', 'revenue'])

            wants_company_list = (
                ('company' in query_lower or 'companies' in query_lower)
                and any(k in query_lower for k in ['show', 'list', 'display', 'all'])
                and not any(k in query_lower for k in ['top', 'bottom', 'highest', 'lowest', 'largest', 'smallest'])
                and not has_numeric_col_mention
                and not has_analytics_keywords
            )
            if wants_company_list and company_col:
                companies = (
                    df[company_col]
                    .dropna()
                    .astype(str)
                    .str.strip()
                )
                companies = companies[companies != '']
                unique_companies = sorted(companies.unique().tolist(), key=lambda s: s.lower())
                result_df = __import__('pandas').DataFrame({company_col: unique_companies})
                st.session_state.last_message = f"✅ Showing {len(unique_companies)} companies"
                st.session_state.last_result_df = result_df
                st.session_state.last_row_indices = []
                found_exact_match = True

            # Continue only if we didn't already fulfill the request above
            if not found_exact_match:
                # Basic stop words that don't help with search
                stop_words = ['the', 'and', 'for', 'from', 'show', 'find', 'get', 'list', 'with',
                              'their', 'revenue', 'revenues', 'chart', 'bar', 'barchart', 'pie',
                              'piechart', 'line', 'linechart', 'scatter', 'graph', 'plot', 'put',
                              'can', 'you', 'me', 'in', 'a', 'all', 'where', 'that', 'which',
                              'are', 'is', 'was', 'were', 'has', 'have', 'had', 'does', 'do',
                              'what', 'who', 'how', 'when', 'give', 'need', 'want', 'please']

                # Entity keywords that hint at which column to search
                entity_hints = {
                    'company': ['company', 'companies', 'firm', 'firms', 'organization', 'organizations', 'corp',
                                'corporation'],
                    'account': ['account', 'accounts', 'client', 'clients'],
                    'portfolio': ['portfolio', 'portfolios', 'fund', 'funds'],
                    'region': ['region', 'regions', 'country', 'countries', 'location'],
                }

                # Detect search modifiers with flexible natural language patterns
                # Patterns like: "starts with john", "starting with john", "begins with john",
                # "name starts with john", "whose name starts with john", "named john*"
                starts_with_patterns = [
                    r'(?:starts?|starting|begins?|beginning)\s+(?:with\s+)?["\']?(\w+)["\']?',
                    r'(?:name|named)\s+["\']?(\w+)["\']?\s*\*',  # "named john*"
                    r'(?:name|named)\s+(?:starts?|starting|begins?|beginning)\s+(?:with\s+)?["\']?(\w+)["\']?',
                    r'whose\s+name\s+(?:starts?|starting|begins?|beginning)\s+(?:with\s+)?["\']?(\w+)["\']?',
                    r'(?:like|matching)\s+["\']?(\w+)\*["\']?',  # "like john*" or "matching john*"
                    r'^["\']?(\w+)\*["\']?$',  # just "john*"
                ]

                ends_with_patterns = [
                    r'(?:ends?|ending)\s+(?:with\s+)?["\']?(\w+)["\']?',
                    r'(?:name|named)\s+(?:ends?|ending)\s+(?:with\s+)?["\']?(\w+)["\']?',
                    r'whose\s+name\s+(?:ends?|ending)\s+(?:with\s+)?["\']?(\w+)["\']?',
                    r'(?:like|matching)\s+["\']?\*(\w+)["\']?',  # "like *john" or "matching *john"
                    r'^\*["\']?(\w+)["\']?$',  # just "*john"
                ]

                starts_with_match = None
                for pattern in starts_with_patterns:
                    match = re.search(pattern, query_lower)
                    if match:
                        starts_with_match = match
                        break

                ends_with_match = None
                for pattern in ends_with_patterns:
                    match = re.search(pattern, query_lower)
                    if match:
                        ends_with_match = match
                        break

                # Determine which entity type user is asking about
                target_entity = None
                for entity, keywords in entity_hints.items():
                    if any(kw in query_lower for kw in keywords):
                        target_entity = entity
                        break

                # Remove entity keywords and stop words to get actual search terms
                all_skip_words = set(stop_words)
                for keywords in entity_hints.values():
                    all_skip_words.update(keywords)
                all_skip_words.update(['starts', 'start', 'starting', 'begins', 'begin', 'beginning',
                                       'ends', 'end', 'ending', 'contains', 'contain', 'containing',
                                       'includes', 'include', 'including'])

                search_terms = [word for word in query_lower.split() if len(word) > 2 and word not in all_skip_words]


                # Find the best column to search based on entity type
                def find_search_column(entity_type):
                    if entity_type == 'company':
                        for col in categorical_cols:
                            if 'company' in col.lower():
                                return col
                    elif entity_type == 'account':
                        for col in categorical_cols:
                            if 'account' in col.lower() or 'client' in col.lower():
                                return col
                    elif entity_type == 'portfolio':
                        for col in categorical_cols:
                            if 'portfolio' in col.lower() or 'fund' in col.lower():
                                return col
                    elif entity_type == 'region':
                        for col in categorical_cols:
                            if 'region' in col.lower() or 'country' in col.lower():
                                return col
                    # Fallback: return first categorical column with 'name' or first one
                    for col in categorical_cols:
                        if 'name' in col.lower():
                            return col
                    return categorical_cols[0] if categorical_cols else None


                # Extract starts_with and ends_with terms directly
                starts_with_term = starts_with_match.group(1).lower() if starts_with_match else None
                ends_with_term = ends_with_match.group(1).lower() if ends_with_match else None

                # If we have starts_with or ends_with, handle them first (before general search)
                if starts_with_term or ends_with_term:
                    search_term = starts_with_term or ends_with_term
                    search_type = "starting with" if starts_with_term else "ending with"

                    # Find the right column to search
                    # If user said company/companies, always force the company column.
                    priority_col = None
                    if target_entity == 'company' and company_col:
                        priority_col = company_col
                    else:
                        priority_col = find_search_column(target_entity) if target_entity else None

                    if not priority_col:
                        # Fallback to first categorical column with 'name' or first one
                        for col in categorical_cols:
                            if 'name' in col.lower() or 'company' in col.lower():
                                priority_col = col
                                break
                        if not priority_col and categorical_cols:
                            priority_col = categorical_cols[0]

                    if priority_col:
                        if starts_with_term:
                            mask = df[priority_col].astype(str).str.lower().str.startswith(starts_with_term)
                        else:
                            mask = df[priority_col].astype(str).str.lower().str.endswith(ends_with_term)

                        if mask.any():
                            result_df = df[mask].copy()
                            entity_name = target_entity if target_entity else "records"
                            st.session_state.last_message = f"✅ Found {len(result_df)} {entity_name} {search_type} '{search_term}'"
                            st.session_state.last_result_df = reorder_columns(result_df, [priority_col])
                            st.session_state.last_row_indices = result_df.index.tolist()
                            if wants_chart:
                                st.session_state.last_chart = create_chart(result_df, search_term.title())
                            found_exact_match = True
                        else:
                            # No matches found - show clear message
                            entity_name = target_entity if target_entity else "records"
                            st.session_state.last_message = f"⚠️ No {entity_name} found {search_type} '{search_term}'"
                            st.session_state.last_result_df = None
                            st.session_state.last_row_indices = []
                            found_exact_match = True  # Prevent fallback to semantic search

                # If we have search terms (and no starts_with/ends_with handled), search for them
                if not found_exact_match and search_terms:
                    # If entity type is detected, prioritize that column
                    if target_entity:
                        priority_col = find_search_column(target_entity)
                        if priority_col:
                            # Search all terms in the priority column
                            for term in search_terms:
                                mask = df[priority_col].astype(str).str.lower().str.contains(term.lower(), na=False,
                                                                                         regex=False)
                                search_type = "matching"

                                if mask.any():
                                    result_df = df[mask].copy()
                                    st.session_state.last_message = f"✅ Found {len(result_df)} {target_entity} records {search_type} '{term}'"
                                    st.session_state.last_result_df = reorder_columns(result_df, [priority_col])
                                    st.session_state.last_row_indices = result_df.index.tolist()
                                    if wants_chart:
                                        st.session_state.last_chart = create_chart(result_df, term.title())
                                    found_exact_match = True
                                    break

                            if not found_exact_match:
                                # Try combining search terms with OR
                                combined_mask = df[priority_col].astype(str).str.lower().str.contains(
                                    '|'.join(search_terms), na=False, regex=True)
                                if combined_mask.any():
                                    result_df = df[combined_mask].copy()
                                    st.session_state.last_message = f"✅ Found {len(result_df)} {target_entity} records matching '{' or '.join(search_terms)}'"
                                    st.session_state.last_result_df = reorder_columns(result_df)
                                    st.session_state.last_row_indices = result_df.index.tolist()
                                    if wants_chart:
                                        st.session_state.last_chart = create_chart(result_df, "Search Results")
                                    found_exact_match = True

                    # If still not found, search across all categorical columns
                    if not found_exact_match:
                        for term in search_terms:
                            for col in categorical_cols:
                                mask = df[col].astype(str).str.contains(term, case=False, na=False, regex=False)
                                if mask.any():
                                    result_df = df[mask].copy()
                                    st.session_state.last_message = f"✅ Found {len(result_df)} records matching '{term}' in {col}"
                                    st.session_state.last_result_df = reorder_columns(result_df, priority_cols)
                                    st.session_state.last_row_indices = result_df.index.tolist()
                                    if wants_chart:
                                        st.session_state.last_chart = create_chart(result_df, term.title())
                                    found_exact_match = True
                                    break
                            if found_exact_match:
                                break

                if not found_exact_match:
                    # Check if any search terms exist in the data at all
                    any_term_exists = False
                    for term in search_terms:
                        for col in categorical_cols:
                            if df[col].astype(str).str.contains(term, case=False, na=False).any():
                                any_term_exists = True
                                break
                        if any_term_exists:
                            break

                    if not any_term_exists and search_terms:
                        # Search terms don't exist in data - show clear message
                        st.session_state.last_message = f"⚠️ '{' '.join(search_terms)}' not found in the data"
                        st.session_state.last_result_df = None
                        st.session_state.last_row_indices = []
                    elif len(df) == 0:
                        st.session_state.last_message = "⚠️ No data available"
                        st.session_state.last_result_df = None
                        st.session_state.last_row_indices = []
                    else:
                        # Use semantic search only if no specific search terms or terms might be partial matches
                        query_vector = vectorizer.transform([query]).toarray()
                        similarities = cosine_similarity(query_vector, vectors).flatten()

                        # Boost results based on learned keywords
                        learned = get_learned_keywords()
                        query_words = query.lower().split()
                        boost_score = sum(learned.get(word, 0) for word in query_words if len(word) > 2)
                        if boost_score > 0:
                            similarities = similarities * (1 + min(boost_score * 0.01, 0.2))

                        # Apply row-specific boosts from past feedback
                        feedback_data = load_feedback()
                        row_boosts = get_row_boosts(query, vectorizer, feedback_data)
                        for row_idx, boost in row_boosts.items():
                            if 0 <= row_idx < len(similarities):
                                similarities[row_idx] = similarities[row_idx] * (1 + min(max(boost * 0.1, -0.5), 0.5))

                        n = min(n, len(df))
                        max_sim = max(similarities) if len(similarities) > 0 else 0

                        # Only show results if there's meaningful similarity
                        if max_sim < 0.01:
                            st.session_state.last_message = f"⚠️ No matching records found for your query"
                            st.session_state.last_result_df = None
                            st.session_state.last_row_indices = []
                        elif n > 0:
                            top_indices = similarities.argsort()[-n:][::-1]
                            result_df = df.iloc[top_indices].copy()
                            st.session_state.last_row_indices = top_indices.tolist()
                            if max_sim > 0.1:
                                st.session_state.last_message = f"✅ Found {len(result_df)} relevant results for your query"
                            else:
                                st.session_state.last_message = f"ℹ️ Showing {len(result_df)} closest matches (low relevance - try different keywords)"
                            st.session_state.last_result_df = reorder_columns(result_df, priority_cols)

                            if wants_chart:
                                st.session_state.last_chart = create_chart(result_df, "Results")
                        else:
                            st.session_state.last_message = "⚠️ No results found"
                            st.session_state.last_result_df = None
                            st.session_state.last_row_indices = []

# Display results from session state
if st.session_state.last_query:
    st.subheader(f"🔎 Results: '{st.session_state.last_query}'")

    if st.session_state.last_message:
        if st.session_state.last_message.startswith("✅"):
            st.success(st.session_state.last_message)
        elif st.session_state.last_message.startswith("ℹ️"):
            st.info(st.session_state.last_message)
        else:
            st.warning(st.session_state.last_message)

    if st.session_state.last_result_df is not None:
        st.dataframe(st.session_state.last_result_df, width='stretch')

        # Display chart if available
        if st.session_state.last_chart is not None:
            # Check if it's a matplotlib figure or plotly figure
            if hasattr(st.session_state.last_chart, 'savefig'):
                # Matplotlib figure
                st.pyplot(st.session_state.last_chart)
                plt.close(st.session_state.last_chart)
            else:
                # Plotly figure
                st.plotly_chart(st.session_state.last_chart, use_container_width=True)

        # Feedback section
        if not st.session_state.feedback_given:
            st.markdown("---")
            st.markdown("**Was this result helpful?**")
            col_yes, col_no, col_space = st.columns([1, 1, 4])
            with col_yes:
                if st.button("👍 Yes", key="feedback_yes"):
                    feedback = load_feedback()
                    feedback['queries'].append({
                        'query': st.session_state.last_query,
                        'timestamp': datetime.now().isoformat(),
                        'helpful': True,
                        'results_count': len(st.session_state.last_result_df)
                    })
                    # Store good keywords
                    words = st.session_state.last_query.lower().split()
                    for word in words:
                        if len(word) > 2:
                            if word not in feedback['good_matches']:
                                feedback['good_matches'][word] = 0
                            feedback['good_matches'][word] += 1
                    # Store row indices for this query (for vector-based learning)
                    query_key = st.session_state.last_query.lower().strip()
                    if query_key not in feedback['query_row_mapping']:
                        feedback['query_row_mapping'][query_key] = {'good_rows': [], 'bad_rows': [], 'score': 0}
                    feedback['query_row_mapping'][query_key]['good_rows'].extend(st.session_state.last_row_indices)
                    feedback['query_row_mapping'][query_key]['score'] += 1
                    save_feedback(feedback)
                    st.session_state.feedback_given = True
                    st.rerun()
            with col_no:
                if st.button("👎 No", key="feedback_no"):
                    feedback = load_feedback()
                    feedback['queries'].append({
                        'query': st.session_state.last_query,
                        'timestamp': datetime.now().isoformat(),
                        'helpful': False,
                        'results_count': len(st.session_state.last_result_df)
                    })
                    # Store bad row indices for this query
                    query_key = st.session_state.last_query.lower().strip()
                    if query_key not in feedback['query_row_mapping']:
                        feedback['query_row_mapping'][query_key] = {'good_rows': [], 'bad_rows': [], 'score': 0}
                    feedback['query_row_mapping'][query_key]['bad_rows'].extend(st.session_state.last_row_indices)
                    feedback['query_row_mapping'][query_key]['score'] -= 1
                    save_feedback(feedback)
                    st.session_state.feedback_given = True
                    st.rerun()
        else:
            st.success("Thanks for your feedback! 🎉")

